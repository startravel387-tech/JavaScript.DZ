// GMAIL CHECKER
const gmailInput = document.querySelector('#gmail_input');
const gmailButton = document.querySelector('#gmail_button');
const gmailResult = document.querySelector('#gmail_result');

const regExp = /^[a-zA-Z0-9._%+-]+@gmail\.com$/;

gmailButton.onclick = () => {
    if (regExp.test(gmailInput.value)) {
        gmailResult.innerHTML = 'OK';
        gmailResult.style.color = 'green';
    } else {
        gmailResult.innerHTML = 'NOT OK';
        gmailResult.style.color = 'red';
    }
};

// MOVE BLOCK
const parentBlock = document.querySelector('.parent_block');
const childBlock = document.querySelector('.child_block');

let posX = 0;
let posY = 0;

const offsetWidth = parentBlock.clientWidth - childBlock.clientWidth;
const offsetHeight = parentBlock.clientHeight - childBlock.clientHeight;

const moveBlock = () => {

    if (posX < offsetWidth && posY === 0) {
        posX++;
        childBlock.style.left = `${posX}px`;
        
        requestAnimationFrame(moveBlock);
    } else if (posX === offsetWidth && posY < offsetHeight) {
        posY++;
        childBlock.style.top = `${posY}px`;
        requestAnimationFrame(moveBlock);
    } else if (posX > 0 && posY === offsetHeight) {
        posX--;
        childBlock.style.left = `${posX}px`;
        requestAnimationFrame(moveBlock);
    } else if (posX === 0 && posY > 0) {
        posY--;
        childBlock.style.top = `${posY}px`;
        requestAnimationFrame(moveBlock);
    }
};

moveBlock();

//TIMER
const secondsDisplay = document.querySelector(`#seconds`);
const startBtn = document.querySelector(`#start`);
const stopBtn = document.querySelector(`#stop`);
const resetBtn = document.querySelector(`#reset`);

let timer = 0;
let interval = null;

const startTimer = () => {
    if (!interval) {
        interval = setInterval(() => {
            timer++;
            secondsDisplay.innerHTML = timer;
        }, 1000);
    }
};

const stopTimer = () => {
    clearInterval(interval);
    interval = null;
};

const resetTimer = () => {
    stopTimer();
    timer = 0;
    secondsDisplay.innerHTML = timer;
};

startBtn.onclick = () => startTimer();
stopBtn.onclick = () => stopTimer();
resetBtn.onclick = () => resetTimer();